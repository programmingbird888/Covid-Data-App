import {useState, useEffect} from 'react';
import './App.css';
import CovidApi from './components/covidApi.js';

function App() {

    const [extract, covidData] = useState([])

    const fetchApiData = () => {
        fetch('https://api.rootnet.in/covid19-in/stats/latest').then(json => {
            return json.json()
        }).then(defaultData => { 
            covidData(defaultData.data.regional)
        })
    } 

    useEffect(() => {
        fetchApiData()
    }, [])

    return (
        
        <div className='container-fluid'>
            <h1 className='heading'>Covid Data</h1>
        <div className='main'>
            {

            extract.map((from) => {
                return <CovidApi location={
                        from.loc
                    }
                    confirmedCases={
                        from.confirmedCasesIndian
                    }
                    confirmedCasesForeign={
                        from.confirmedCasesForeign
                    }
                    discharged={
                        from.discharged
                    }
                    deaths={
                        from.deaths
                    }
                    totalConfirmed={
                        from.totalConfirmed
                    }/>


            })
        } </div>
        </div>
    );
}


export default App;
