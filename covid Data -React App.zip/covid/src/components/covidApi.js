import React from 'react'
import "../index.css"
export default function CovidApi(props) {
    return (

            <div className="card mycard">
                <div className="card-header background">
                    <h2 className="card-title colors">
                        {
                        props.location
                    }</h2>
                </div>
                <ul className="list-group list-group-flush">
                    <li className="list-group-item">
                        <p className="card-text">
                            <b>Confirmed Cases:</b>&nbsp;{
                            props.confirmedCases
                        }</p>
                    </li>
                    <li className="list-group-item">
                        <p className="card-text">
                            <b>Confirmed Cases Indian:</b>&nbsp;{
                            props.confirmedCases
                        }</p>
                    </li>
                    <li className="list-group-item">
                        <p className="card-text">
                            <b>Discharged Cases:</b>&nbsp;{
                            props.discharged
                        }</p>
                    </li>
                    <li className="list-group-item">
                        <p className="card-text">
                            <b>Deaths:</b>&nbsp;{
                            props.deaths
                        }</p>
                    </li>
                    <li className="list-group-item">
                        <p className="card-text">
                            <b>Total Confirmed Cases:</b>&nbsp;{
                            props.totalConfirmed
                        }</p>
                    </li>
                </ul>
                </div>
        // </div>


    )
}
